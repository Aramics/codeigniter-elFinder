<h2>Tipy na obsluhu</h2>
<p>Obsluha na uživatelském rozhraní je podobná standardnímu správci souborů operačního systému. Drag and Drop však není možné používat s mobilními prohlížeči. </p>
<ul>
	<li>Kliknutím pravým tlačítkem nebo dlouhým klepnutím zobrazíte kontextové menu.</li>
	<li>Přetáhněte do stromu složek nebo do aktuálního pracovního prostoru a přetáhněte / kopírujte položky.</li>
	<li>Výběr položky v pracovním prostoru můžete rozšířit pomocí kláves Shift nebo Alt (Možnost).</li>
	<li>Přemístěte soubory a složky do cílové složky nebo do pracovního prostoru.</li>
	<li>Dialog předávání může přijímat data schránky nebo seznamy adres URL a přitáhnout a odejít z jiných prohlížečů nebo správců souborů.</li>
	<li>Zatažením spusťte stisknutím klávesy Alt (Možnost) přetáhněte do vnějšího prohlížeče. Tato funkce se převezme pomocí prohlížeče Google Chrome.</li>
</ul>
